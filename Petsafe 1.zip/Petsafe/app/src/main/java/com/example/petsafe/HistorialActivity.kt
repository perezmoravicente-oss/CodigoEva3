package com.example.petsafe

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray

class HistorialActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historial)

        val btnVolver = findViewById<Button>(R.id.btnVolver)
        val txtHistorial = findViewById<TextView>(R.id.txtHistorial)

        btnVolver.setOnClickListener {
            finish()
        }

        txtHistorial.text = "Cargando alertas..."

        Thread {
            var conexion: HttpURLConnection? = null

            try {
                val url = URL("http://192.168.100.13:5000/alertas")
                conexion = url.openConnection() as HttpURLConnection
                conexion.requestMethod = "GET"
                conexion.connectTimeout = 5000
                conexion.readTimeout = 5000

                val respuesta = conexion.inputStream.bufferedReader().use {
                    it.readText()
                }

                val alertas = JSONArray(respuesta)
                val historial = StringBuilder()

                for (i in 0 until alertas.length()) {
                    val alerta = alertas.getJSONObject(i)

                    historial.append("Alerta: ")
                    historial.append(alerta.getString("tipo_alerta"))
                    historial.append("\n")

                    historial.append("Fecha: ")
                    historial.append(alerta.getString("fecha"))
                    historial.append("\n")

                    historial.append("Descripción: ")
                    historial.append(alerta.getString("descripcion"))
                    historial.append("\n\n")
                }

                runOnUiThread {
                    txtHistorial.text = if (alertas.length() == 0) {
                        "No hay alertas registradas"
                    } else {
                        historial.toString()
                    }
                }

            } catch (e: Exception) {
                runOnUiThread {
                    txtHistorial.text = "Error al cargar las alertas: ${e.message}"
                }
            } finally {
                conexion?.disconnect()
            }
        }.start()
    }
}
