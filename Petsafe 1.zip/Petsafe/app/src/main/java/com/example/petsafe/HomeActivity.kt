
package com.example.petsafe

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class HomeActivity : AppCompatActivity() {

    private val servidor = "http://192.168.100.13:5000"
    private val urlAlarma = "$servidor/alarma"
    private val urlEstado = "$servidor/estado"

    private lateinit var txtEstadoSistema: TextView
    private lateinit var txtEstadoMascota: TextView
    private lateinit var txtUltimaDeteccion: TextView
    private lateinit var txtEstadoConexion: TextView

    private val handler = Handler(Looper.getMainLooper())

    @Volatile
    private var consultando = false

    private val actualizador = object : Runnable {
        override fun run() {
            consultarEstado()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        txtEstadoSistema = findViewById(R.id.txtEstadoSistema)
        txtEstadoMascota = findViewById(R.id.txtEstadoMascota)
        txtUltimaDeteccion = findViewById(R.id.txtUltimaDeteccion)
        txtEstadoConexion = findViewById(R.id.txtEstadoConexion)

        val btnActivarAlarma =
            findViewById<Button>(R.id.btnActivarAlarma)

        val btnDesactivarAlarma =
            findViewById<Button>(R.id.btnDesactivarAlarma)

        val btnHistorial =
            findViewById<Button>(R.id.btnHistorial)

        val btnCerrarSesion =
            findViewById<Button>(R.id.btnCerrarSesion)

        txtEstadoSistema.text = "SIN VERIFICAR"
        txtEstadoMascota.text = "SIN VERIFICAR"
        txtUltimaDeteccion.text = "Sin movimientos detectados"
        txtEstadoConexion.text = "Consultando..."

        btnActivarAlarma.setOnClickListener {
            enviarComando("activar")
        }

        btnDesactivarAlarma.setOnClickListener {
            enviarComando("desactivar")
        }

        btnHistorial.setOnClickListener {
            val intent = Intent(
                this,
                HistorialActivity::class.java
            )
            startActivity(intent)
        }

        btnCerrarSesion.setOnClickListener {
            val intent = Intent(
                this,
                MainActivity::class.java
            )
            startActivity(intent)
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(actualizador)
        handler.post(actualizador)
    }

    override fun onPause() {
        handler.removeCallbacks(actualizador)
        super.onPause()
    }

    private fun enviarComando(accion: String) {

        txtEstadoConexion.text = "Enviando instrucción..."

        Thread {
            var conexion: HttpURLConnection? = null

            try {
                conexion = URL(urlAlarma)
                    .openConnection() as HttpURLConnection

                conexion.requestMethod = "POST"
                conexion.setRequestProperty(
                    "Content-Type",
                    "application/json"
                )
                conexion.connectTimeout = 5000
                conexion.readTimeout = 5000
                conexion.doOutput = true

                val datos = JSONObject()
                datos.put("accion", accion)

                conexion.outputStream.use { salida ->
                    salida.write(
                        datos.toString()
                            .toByteArray(Charsets.UTF_8)
                    )
                }

                val codigo = conexion.responseCode

                runOnUiThread {
                    if (codigo == 200) {

                        txtEstadoConexion.text =
                            "Comando enviado. Verificando..."

                        val mensaje = if (accion == "activar") {
                            "Orden de activar alarma enviada"
                        } else {
                            "Orden de desactivar alarma enviada"
                        }

                        Toast.makeText(
                            this,
                            mensaje,
                            Toast.LENGTH_SHORT
                        ).show()

                        consultarEstado()

                    } else {
                        txtEstadoConexion.text =
                            "Error de comunicación"

                        Toast.makeText(
                            this,
                            "Error del servidor: $codigo",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

            } catch (e: Exception) {
                runOnUiThread {
                    txtEstadoConexion.text = "Sin conexión"

                    Toast.makeText(
                        this,
                        "No se pudo conectar con Raspbian",
                        Toast.LENGTH_LONG
                    ).show()
                }

            } finally {
                conexion?.disconnect()
            }
        }.start()
    }

    private fun consultarEstado() {

        if (consultando) return
        consultando = true

        Thread {
            var conexion: HttpURLConnection? = null

            try {
                conexion = URL(urlEstado)
                    .openConnection() as HttpURLConnection

                conexion.requestMethod = "GET"
                conexion.connectTimeout = 5000
                conexion.readTimeout = 5000

                if (conexion.responseCode == 200) {

                    val respuesta =
                        conexion.inputStream.bufferedReader().use {
                            it.readText()
                        }

                    val datos = JSONObject(respuesta)

                    val estado = datos.optString(
                        "estado",
                        "SIN_VERIFICAR"
                    )

                    runOnUiThread {

                        when (estado) {

                            "SISTEMA_ACTIVADO" -> {
                                txtEstadoSistema.text = "ACTIVO"
                                txtEstadoMascota.text = "SEGURA"
                                txtUltimaDeteccion.text =
                                    "Sin movimientos detectados"
                                txtEstadoConexion.text =
                                    "Conectado con dispositivo IoT"
                            }

                            "SISTEMA_DESACTIVADO" -> {
                                txtEstadoSistema.text = "DESACTIVADO"
                                txtEstadoMascota.text = "SEGURA"
                                txtUltimaDeteccion.text =
                                    "Sin movimientos detectados"
                                txtEstadoConexion.text =
                                    "Conectado con dispositivo IoT"
                            }

                            "MOVIMIENTO_DETECTADO" -> {
                                txtEstadoSistema.text =
                                    "MOVIMIENTO DETECTADO"
                                txtEstadoMascota.text =
                                    "MOVIMIENTO DETECTADO"
                                txtUltimaDeteccion.text =
                                    "Movimiento registrado por el sensor PIR"
                                txtEstadoConexion.text =
                                    "Alerta recibida del sensor PIR"
                            }

                            "ZONA_SEGURA" -> {
                                txtEstadoSistema.text = "ACTIVO"
                                txtEstadoMascota.text = "SEGURA"
                                txtUltimaDeteccion.text =
                                    "Sin movimiento actualmente"
                                txtEstadoConexion.text =
                                    "Conectado con dispositivo IoT"
                            }

                            else -> {
                                txtEstadoSistema.text = "SIN VERIFICAR"
                                txtEstadoMascota.text = "SIN VERIFICAR"
                                txtUltimaDeteccion.text =
                                    "Estado no disponible"
                                txtEstadoConexion.text =
                                    "Estado no disponible"
                            }
                        }
                    }

                } else {
                    runOnUiThread {
                        txtEstadoSistema.text = "SIN VERIFICAR"
                        txtEstadoMascota.text = "SIN VERIFICAR"
                        txtEstadoConexion.text =
                            "Error al consultar dispositivo"
                    }
                }

            } catch (e: Exception) {
                runOnUiThread {
                    txtEstadoSistema.text = "SIN VERIFICAR"
                    txtEstadoMascota.text = "SIN VERIFICAR"
                    txtEstadoConexion.text =
                        "No se pudo consultar el estado"
                }

            } finally {
                conexion?.disconnect()
                consultando = false
            }
        }.start()
    }
}
